from ..models import probability


class SemanticAgent:
    """Owner proposal: Беседин Артем. Tool: instruction lookup / neighbor request."""
    name = "semantic"

    def run(self, record, spec, provider, neighbors=None):
        if provider.mode == "llm":
            result = provider.ask(self.name, {"text": record.text, "classes": spec["classes"],
                                  "rules": spec["rules"], "additional_evidence": neighbors or []})
        else:
            normalized = record.text.lower().replace("ё", "е")
            hits = {c["id"]: [word for word in c.get("keywords", []) if word in normalized] for c in spec["classes"]}
            labels = [label for label, words in hits.items() if words]
            result = {"labels": labels, "confidence": 0.82 if len(labels) == 1 else 0.35,
                      "evidence": record.text,
                      "reason": "Признаки: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in hits.items() if v) if labels else "Нет известных признаков; нужен человек.",
                      "needs_neighbors": len(labels) != 1}
        valid = {c["id"] for c in spec["classes"]}
        labels = result.get("labels")
        if not isinstance(labels, list) or not all(isinstance(x, str) and x in valid for x in labels) or len(labels) != len(set(labels)):
            raise ValueError("Семантический агент вернул неизвестные или повторные классы.")
        result["confidence"] = probability(result.get("confidence"))
        evidence = result.get("evidence")
        if not isinstance(evidence, str) or not evidence.strip() or evidence not in record.text:
            raise ValueError("Цитата семантического агента отсутствует в исходном тексте.")
        if not isinstance(result.get("reason"), str) or not isinstance(result.get("needs_neighbors"), bool):
            raise ValueError("Семантический агент нарушил контракт.")
        return result

